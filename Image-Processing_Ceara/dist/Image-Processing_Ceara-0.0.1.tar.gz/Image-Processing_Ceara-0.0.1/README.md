# package_name

Description. 
The package package_name is used to:
	- Plot Hist
	- Plot Image
	- Conversion RGB to GRAY
	- Conversion RGB to HSV

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install image-processing-ceara
```

## Author
Iago Magalhães de Mesquita

## License
[MIT](https://choosealicense.com/licenses/mit/)